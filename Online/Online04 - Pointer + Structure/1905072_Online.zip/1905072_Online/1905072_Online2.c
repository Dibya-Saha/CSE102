#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char* construct(char *s,char *t)
{
	int n=strlen(s),m=strlen(t),i,j,Size=n;
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			if(*(s+j)==*(t+i))
			{
				if(*(s+j)>0) Size--;
			 	*(s+j)=0;
			}
		}
	}

	char *ANS=(char*)malloc(sizeof(char)*Size);

	for(i=j=0;i<n;i++)
	{
		if(*(s+i)>0) 
		{
			*(ANS+j)=*(s+i);
			j++;
		}
	}
	*(ANS+j)='\0';
	return ANS;
}

int main()
{
	char *s,*t;
	s=(char*)malloc(sizeof(char)*100);
	t=(char*)malloc(sizeof(char)*100);
	gets(s);
	gets(t);
	char *ANS=construct(s,t);
	puts(ANS);
	free(s);
	free(t);
	free(ANS);
}