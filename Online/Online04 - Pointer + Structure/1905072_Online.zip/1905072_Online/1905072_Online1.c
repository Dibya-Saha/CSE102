#include<stdio.h>
#include<math.h>
struct Point
{
	double x;
	double y;
};

struct Circle
{
	struct Point center;
	double radius;
};

struct Rectangle
{
	struct Point TL,BR;
};

double Length(struct Point A,struct Point B)
{
	return sqrt(((A.x-B.x)*(A.x-B.x))+((A.y-B.y)*(A.y-B.y)));
}
double area_rect(struct Rectangle r)
{
	struct Point BL={r.TL.x,r.BR.y};
	return Length(BL,r.TL)*Length(BL,r.BR);
}

int rect_inside_circle(struct Circle c, struct Rectangle r)
{
	return (Length(r.TL,c.center)<=c.radius&&Length(r.BR,c.center)<=c.radius);
}
int main()
{
	struct Circle c;
	struct Rectangle r;
	scanf("%lf %lf %lf",&c.center.x,&c.center.y,&c.radius);
	scanf("%lf %lf %lf %lf",&r.TL.x,&r.TL.y,&r.BR.x,&r.BR.y);
	printf("Area of rectangle: %lf\n",area_rect(r));
	if(rect_inside_circle(c,r))
	{
		puts("Inside");
	}
	else
	{
		puts("Not inside");
	}
	return 0;
}
