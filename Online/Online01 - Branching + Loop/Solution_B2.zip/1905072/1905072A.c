#include<stdio.h>

int main()
{
	int x,b,n=0,i; 
	scanf("%d %d",&x,&b);
	
	for(i=1;x!=0;i*=b)
	{
		n+=(x%10)*i;
		x/=10;
	}
	printf("%d\n",n);
}