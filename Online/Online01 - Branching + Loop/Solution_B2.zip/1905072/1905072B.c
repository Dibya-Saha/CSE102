#include<stdio.h>

int main()
{
   int n,a=0,i; 

   scanf("%d",&n);

    while(n) 
   	{
   		a=a*10+n%10;
   		n/=10;
   	} 
    
   for(i=2;i*i<=a;i++) 
   	{
   		if(!(a%i)) break; 
   	}

   if(i*i>a&&a>1) printf("Yes\n"); 
   else printf("No\n");

}