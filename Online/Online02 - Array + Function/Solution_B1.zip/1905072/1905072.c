#include<stdio.h>

int prime(long long n)
{
	int i;
	for(i=2;i*i<=n;i++) 
	{
		if(!(n%i)) break;
	}	
    return i*i>n;
}

long long ncr(long long n,long long r)
{
    long long s=1,i; 

	for(i=1;i<=r;i++)
		{
			s=(s*(n-r+i))/i; 
		}
	return s;
}

int main()
{
	long long n,i,c=0,s=0,last_prime=2;
	scanf("%lld",&n);

	for(i=3;c<n;i++)
	{
		if(prime(i))
		{
            c++;
		    s+=ncr(i,last_prime);
		    last_prime=i;					
		}
	}
	printf("%lld",s);
}