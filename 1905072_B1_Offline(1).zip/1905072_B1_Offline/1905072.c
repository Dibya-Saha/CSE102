#include<stdio.h>

int exist,x[30],visited[30],n;

void path(int i)
{
	if(exist) return;                //path is already found
	if(i>n-1) return;                //out of limit
	if(i<0) return;                  //out of limit
	if(visited[i]) return;           //slot is already visited 
	if(i==n-1) {exist=1; return;}    //path exist
	if(!x[i]) return;                //stands on 0 

	visited[i]=1;
	path(i+x[i]);
	path(i-x[i]);
}

int main()
{
	int i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x[i]);
	}

	path(0);
	if(exist) puts("Yes");
	else puts("No");
}