#include<stdio.h>

int main()
{
    int n,a,x[20001]={},i,j,m,first;
    scanf("%d",&n);

    while(n--)
    {
        scanf("%d",&a);

        x[10000+a]++;   //store the frequency of numbers

        m=0;
        first=1;

        for(i=0;i<20001;i++)
        {
            if(x[i]>m) m=x[i];   //find the maximum frequency
        }


        for(i=0;i<20001;i++)     //find the most frequent number
        {
            if(x[i]==m)
            {
                if(first)
                {
                    printf("Most frequent number = %d",i-10000);
                    first=0;
                }
                else
                {
                    printf(", %d",i-10000);
                }
            }
        }
        printf("\n");
    }

}
