#include<stdio.h>

int main()
{
    int n,x[1000],i,j,m=0;
    scanf("%d",&n);

    for(i=0; i<n; i++)
    {
        scanf("%d",&x[i]);
        if(x[i]>m) m=x[i];  //find the maximum height
    }

    for(i=0; i<m; i++)
    {
        for(j=0; j<2*n-1; j++) //total width is 2n-1
        {
            if(j%2==0)
            {
                if(m-i<=x[j/2])
                {
                    printf("**");
                }
                else
                {
                    printf("  ");
                }
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
    }
}
