#include<stdio.h>
#include<string.h>

int i, j, k;

int StringToInt(char s[], int start, int end)
{
    int n = 0;
    int i;
    for (i = start; i < end; i++)
    {
        n *= 10;
        s[i] -= '0';
        n += s[i];
    }
    return n;
}

void Trim(char s[])
{
    char t[100];
    for (i = j = 0; s[i] != '\0'; i++)
    {
        if (s[i] != ' ')
        {
            t[j++] = (s[i] > 96) ? s[i] - 32 : s[i];
        }
    }
    for (i = 0; i < j; i++)
    {
        s[i] = t[i];
    }
    s[i] = '\0';
}
void Input(int x[][5], int r, int c)
{
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            scanf("%d", &x[i][j]);
        }
    }
}
void Output(int x[][5], int r, int c)
{
    for (i = 0; i < r; i++)
    {
        puts("");
        for (j = 0; j < c; j++)
        {
            printf("%10d ", x[i][j]);
        }
        puts("");
    }
    puts("");
}
void Add(int x[][5], int y[][5], int r, int c)
{
    int mat[5][5];
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            mat[i][j] = x[i][j] + y[i][j];
        }
    }
    Output(mat, r, c);
}
void Substract(int x[][5], int y[][5], int r, int c)
{
    int mat[5][5];
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            mat[i][j] = x[i][j] - y[i][j];
        }
    }
    Output(mat, r, c);
}
void Multiply(int x[][5], int y[][5], int rx, int cx, int cy)
{
    int mat[5][5];
    for (i = 0; i < rx; i++)
    {
        for (j = 0; j < cy; j++)
        {
            mat[i][j] = 0;
            for (k = 0; k < cx; k++)
            {
                mat[i][j] += (x[i][k] * y[k][j]);
            }
        }
    }
    Output(mat, rx, cy);
}
void Divide(int x[][5], int r, int c, int n)
{
    float mat[5][5];
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            mat[i][j] = 1.0 * x[i][j] / n;
        }
    }
    for (i = 0; i < r; i++)
    {
        puts("");
        for (j = 0; j < c; j++)
        {
            printf("%10f ", mat[i][j]);
        }
        puts("");
    }
    puts("");
}


void Transpose(int x[][5], int r, int c)
{
    int trans[5][5];
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            trans[j][i] = x[i][j];
        }
    }
    Output(trans, c, r);
}

void Cofactor(int mat[][5], int temp[][5], int r, int c, int n)
{
    int i = 0, j = 0, row, col;
    for (row = 0; row < n; row++)
    {
        for (col = 0; col < n; col++)
        {
            if (row != r && col != c)
            {
                temp[i][j++] = mat[row][col];
                if (j == n - 1)
                {
                    j = 0;
                    i++;
                }
            }
        }
    }
}

int Determinant(int mat[][5], int n)
{
    int Det = 0;
    if (n == 1)
        return mat[0][0];

    int temp[5][5], sign = 1, i;

    for (i = 0; i < n; i++)
    {
        Cofactor(mat, temp, 0, i, n);
        Det += (sign * mat[0][i] * Determinant(temp, n - 1));
        sign *= -1;
    }

    return Det;
}

int main()
{
    char s[100];
    int A[5][5], B[5][5], Ar = -1, Ac = -1, Br = -1, Bc = -1;

    while (1)
    {
        scanf("\n");
        gets(s);
        Trim(s);
        switch (s[1])
        {
        case 'X': return 0;
        case 'N':
            if (s[strlen(s) - 1] == 'A')
            {
                printf("Enter Dimension of A : ");
                scanf("%d %d", &Ar, &Ac);
                printf("Enter matrix A (%d X %d) :\n", Ar, Ac);
                Input(A, Ar, Ac);
                printf("Matrix A is Inserted\n\n");
            }
            else if (s[strlen(s) - 1] == 'B')
            {
                printf("Enter Dimension of B : ");
                scanf("%d %d", &Br, &Bc);
                printf("Enter matrix B (%d X %d) :\n", Br, Bc);
                Input(B, Br, Bc);
                printf("Matrix B is Inserted\n\n");
            }
            else
            {
                puts("Invalid input\n");
            }
            break;

        case 'U':
            if (s[strlen(s) - 1] == 'A')
            {
                if (Ar > -1)
                {
                    printf("Matrix A (%d X %d) :\n", Ar, Ac);
                    Output(A, Ar, Ac);
                }
                else
                {
                    printf("No A matrix found\n\n");
                }

            }
            else if (s[strlen(s) - 1] == 'B')
            {
                if (Ar > -1)
                {
                    printf("Matrix B (%d X %d) :\n", Br, Bc);
                    Output(B, Br, Bc);
                }
                else
                {
                    printf("No B matrix found\n\n");
                }
            }
            else
            {
                puts("Invalid input\n");
            }
            break;
        case 'R':
            if (s[strlen(s) - 1] == 'A')
            {
                if (Ar > -1)
                {
                    Transpose(A, Ar, Ac);
                }
                else
                {
                    printf("No A matrix found\n\n");
                }

            }
            else if (s[strlen(s) - 1] == 'B')
            {
                if (Br > -1)
                {
                    Transpose(B, Br, Bc);
                }
                else
                {
                    printf("No B matrix found\n\n");
                }
            }
            else
            {
                puts("Invalid input\n");
            }

            break;

        case '+':
            if ((s[0] == 'A' || s[0] == 'B' )&& (s[strlen(s) - 1] == 'A' || s[strlen(s) - 1] == 'B'))
            {
                if (Ar > -1 && Br > -1)
                {
                    if (Ar == Br && Ac == Bc)
                    {
                        Add(A, B, Ar, Ac);
                    }
                    else
                    {
                        puts("Addition not possible");
                    }

                }
                else
                {
                    if (Ar == -1)
                    {
                        puts("No A matrix found");
                    }
                    if (Br == -1)
                    {
                        puts("No B matrix found");
                    }
                }
            }
            else
            {
                puts("Invalid input\n");
            }
            break;

        case '-':
            if ((s[0] == 'A' || s[0] == 'B' )&&( s[strlen(s) - 1] == 'A' || s[strlen(s) - 1] == 'B'))
            {   if (Ar > -1 && Br > -1)
                {
                    if (Ar == Br && Ac == Bc)
                    {
                        if (s[0] == 'A')
                        {
                            Substract(A, B, Ar, Ac);
                        }
                        else if (s[0] == 'B')
                        {
                            Substract(B, A, Br, Bc);
                        }

                    }
                    else
                    {
                        puts("Substraction not possible");
                    }
                }
                else
                {
                    if (Ar == -1)
                    {
                        puts("No A matrix found");
                    }
                    if (Br == -1)
                    {
                        puts("No B matrix found");
                    }
                }
            }
            else
            {
                puts("Invalid input\n");
            }
            break;

        case '/':
            if (s[0] == 'A')
            {
                if (Ar > -1)
                {
                    if(s[strlen(s)-1]>='0'&&s[strlen(s)-1]<='9')
                    {
                        int n = StringToInt(s, 2, strlen(s));
                        if (n != 0)
                        {
                            Divide(A, Ar, Ac, n);
                        }
                    }
                    else
            {
                puts("Invalid input\n");
            }
                }
                else
                {
                    puts("No A matrix found");
                }
            }
            else if (s[0] == 'B')
            {
                if (Br > -1)
                {
                    if(s[strlen(s)-1]>='0'&&s[strlen(s)-1]<='9')
                    {int n = StringToInt(s, 2, strlen(s));
                    if (n != 0)
                    {
                        Divide(B, Br, Bc, n);
                    }}
                    else
            {
                puts("Invalid input\n");
            }

                }
                else
                {
                    puts("No B matrix found");
                }
            }
            else
            {
                puts("Invalid input\n");
            }
            break;

        case '*':
            if ((s[0] == 'A' || s[0] == 'B')&& (s[strlen(s) - 1] == 'A' || s[strlen(s) - 1] == 'B'))
            {
                if (Ar > -1 && Br > -1)
                {
                    if (Ac == Br)
                    {
                        if (s[0] == 'A')
                        {
                            Multiply(A, B, Ar, Ac, Bc);
                        }
                        else if (s[0] == 'B')
                        {
                            Multiply(B, A, Br, Bc, Ac);
                        }

                    }
                    else
                    {
                        puts("Multiplication not possible");
                    }
                }
                else
                {
                    if (Ar == -1)
                    {
                        puts("No A matrix found");
                    }
                    if (Br == -1)
                    {
                        puts("No B matrix found");
                    }
                }
            }
            else
            {
                puts("Invalid input\n");
            }
            break;
        case 'E':
            if (s[strlen(s) - 1] == 'A')
            {
                if (Ar > -1)
                {
                    if (Ar == Ac)
                    {
                        printf("%d\n", Determinant(A, Ar));
                    }
                    else
                    {
                        puts("Determinant not possible");
                        printf("%d %d\n", Ar, Ac);
                    }
                }
                else
                {
                    puts("No A matrix found");
                }
            }
            else if (s[strlen(s) - 1] == 'B')
            {
                if (Br > -1)
                {
                    if (Br == Bc)
                    {
                        printf("%d\n", Determinant(B, Br));
                    }
                    else
                    {
                        puts("Determinant not possible");
                    }
                }
                else
                {
                    puts("No B matrix found");
                }
            }
            else
            {
                puts("Invalid input\n");
            }
            break;

        default:
            if(s[0]<'0'||s[0]>'9')
            puts("Invalid input\n");
            break;
        }
    }

}

